package main

import (
	"fmt"

	"quad/piscine"
)

type quadFunc func(int, int)

func main() {
	qFuncs := []quadFunc{piscine.QuadA, piscine.QuadB, piscine.QuadC, piscine.QuadD, piscine.QuadE}

	println()
	for i, f := range qFuncs {

		fmt.Printf("... Quad%c ...\n", 'A'+i)
		println()
		f(5, 3)
		println()
		f(5, 1)
		println()
		f(1, 1)
		println()
		f(1, 5)
		println()
	}
}
